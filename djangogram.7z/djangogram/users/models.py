from django.db import models

# Create your models here.

# from django.contrib.auth.models import User 

class User(models.Model):
    user = models.CharField(max_length=50, primary_key=True)
    password = models.CharField(max_length=255)
    phone = models.IntegerField(blank=True)
    email = models.EmailField(max_length=255)
    name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    photo = models.ImageField(upload_to='users/pictures', blank=True, null=True)
    created = models.DateTimeField(auto_now_add=True)
    modified = models.DateTimeField(auto_now=True)

    def __str__(self):
        """Return Email"""
        return self.user.username
