from users.models import User

class Validation():
    def __init__(self):
        self.message = {}

    def isEmpty(self, campo):
        self.message['estado'] = 0
        self.message['message'] = 'El campo {} no puede estar vacío'.format(campo)
        if len(str(campo)) <= 0:
            self.message['estado'] <= 1
        
        return self.message

    def validateUser(self, username):
        self.message['estado'] = 0
        self.message['message'] = 'El usuario {} ya existe'.format(username)
        username_taken = User.objects.filter(user=username).exists()
        if username_taken :
            self.message['estado'] = 1
        
        return self.message

    def validateEmail(self, email):
        self.message['estado'] = 0
        self.message['message'] = 'El email {} ya existe'.format(email)
        email_taken = User.objects.filter(email=email).exists()
        if email_taken :
            self.message['estado'] = 1
        
        return self.message