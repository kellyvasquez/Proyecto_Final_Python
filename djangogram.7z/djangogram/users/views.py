from django.shortcuts import render, redirect
from users.validation import Validation
import hashlib
from users.models import User
from stories.models import follower
from django.db.utils import IntegrityError
from django.http import JsonResponse

def my_login_required(function):
    def wrapper(request, *args, **kw): 
        if not (request.session.get('login')):
            return redirect('/users/login')
        else:
            return function(request, *args, **kw)
    return wrapper

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = hashlib.sha256(request.POST['password'].encode()).hexdigest()
        user = User.objects.filter(user=request.POST['username'], password=password).exists()
        if user:
            user = User.objects.get(user=request.POST['username'], password=password)
            request.session['login'] = 1
            request.session['user_id'] = user.user
            request.session['user'] = username
            return redirect('posts')
        else:
            return render(request, 'users/login.html', {'error': user})
    return render(request, 'users/login.html')

def logout_view(request):
    if request.session.get('login') == 1:
        del request.session['login']
        del request.session['user_id']
        del request.session['user']
    return redirect('/users/login')

def signup(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        password_confirmation = request.POST['password_confirmation']
        name = request.POST['name']
        last_name = request.POST['last_name']
        email = request.POST['email']
        phone = request.POST['phone']

        validator = Validation()
        validate = validator.validateUser(username)
        if(validate.get('estado') == 1):
            return render(request, 'users/signup.html', {'error' : validate.get('message')})

        validate = validator.validateEmail(email)
        if(validate.get('estado') == 1):
            return render(request, 'users/signup.html', {'error' : validate.get('message')})


        if validator.isEmpty(username).get('estado') or validator.isEmpty(name).get('estado') or validator.isEmpty(email).get('estado') or validator.isEmpty(phone).get('estado'):
            return render(request, 'users/signup.html', {'error' : 'Debe completar todos los campos'})
        
        if password != password_confirmation:
            return render(request, 'users/signup.html', {'error' : 'Las contraseñas no coinciden'})

        try:
            password = hashlib.sha256(password.encode()).hexdigest()
            usuario = User.objects.create(user=username, password=password, name=name, last_name=last_name, email=email, phone=phone)
            request.session['login'] = 1
            request.session['user_id'] = usuario.user
            request.session['user'] = username
            return redirect('posts')
        except IntegrityError:
            return render(request, 'users/signup.html', {'error' : 'Ocurrió un error'})
        
        return redirect('login')

    return render(request, 'users/signup.html')


@my_login_required
def profile(request):
    #perfil = User.objects.get(user=request.session.get('user_id'))
    perfil = User.objects.raw('''
                select * from users_user
                left join (select user_id as user_storie, count(*)as publicaciones from stories_post group by user_id) as publicaciones on
                users_user.user = publicaciones.user_storie 
                left join (select user_id, count(*) as seguidores from stories_follower group by user_id) as seguidores on
                users_user.user = seguidores.user_id 
                left join (select follower_user_id, count(*) as seguidos from stories_follower group by follower_user_id) as seguidos on
                users_user.user = seguidos.follower_user_id 
                where users_user.user = '{}'
                '''.format(request.session.get('user_id')))
    return render(request, 'users/update_profile.html', {'user': perfil[0]})

@my_login_required
def update_profile(request):
    if request.method == 'POST':
        id = User.objects.get(user = request.session.get('user_id'))
        id.name = request.POST['name']
        id.last_name = request.POST['last_name']
        id.email = request.POST['email']
        id.phone = request.POST['phone']
        if request.FILES:
            id.photo = request.FILES['photo']
        id.save()
    return redirect('/users/profile/')

@my_login_required
def followers(request):
    if request.method == 'POST':
        search = request.POST['search'].upper()
        #followerall = User.objects.all().filter(user__contains=search)
        followerall = User.objects.raw('''
                select * from users_user
                left join (select user_id as user_storie, count(*)as publicaciones from stories_post group by user_id) as publicaciones on
                users_user.user = publicaciones.user_storie 
                left join (select user_id as user_seguidor, count(*) as seguidores from stories_follower group by user_id) as seguidores on
                users_user.user = seguidores.user_seguidor
                left join (select follower_user_id, count(*) as seguidos from stories_follower group by follower_user_id) as seguidos on
                users_user.user = seguidos.follower_user_id 
                where (upper(user) like '%%{}%%' or upper(name) like '%%{}%%' or upper(last_name) like '%%{}%%' or upper(email) like '%%{}%%') and users_user.user != '{}'
                '''.format(search, search, search, search, request.session.get('user_id')))
        #followerall = User.objects.select_related('follower')
        for follow in followerall:
            follow.seg = follower.objects.all().filter(user_id=follow.user_seguidor, follower_user_id=request.session.get('user_id')).exists()

    perfil = User.objects.get(user=request.session.get('user_id'))
    return render(request, 'users/followers.html', {'followers':followerall, 'user': perfil})

@my_login_required
def follow(request):
    if request.method == 'POST':
        idfoller = request.POST['idfollower']
        followerselect = follower.objects.all().filter(user_id=idfoller, follower_user_id=request.session.get('user_id'))
        if followerselect.exists():
            followerselect.delete()
            response = 'delete'
        else:
            follower.objects.create(user_id=idfoller, follower_user_id=request.session.get('user_id'))
            response = 'create'
        return JsonResponse({'response': response})
    return redirect('/users/login/')



