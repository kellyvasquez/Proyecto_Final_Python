"""djangogram URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

from django.conf.urls.static import static
from django.conf import settings
from users import views as views_users
from stories import views as views_posts

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views_posts.listar_posts, name='inicio'),
    path('users/login/', views_users.login_view, name='login'),
    path('users/logout/', views_users.logout_view, name='logout'),
    path('users/signup/', views_users.signup, name='signup'),
    path('users/profile/', views_users.profile, name='profile'),
    path('users/update_profile/', views_users.update_profile, name='profile'),
    path('users/followers/', views_users.followers, name='followers'),
    path('users/follow/', views_users.follow, name='follow'),
    path('posts', views_posts.listar_posts, name='posts'),
    path('posts/new', views_posts.new, name='posts_new'),
    path('posts/create_post', views_posts.create_post, name='posts_create'),
    path('posts/like', views_posts.action_like, name='posts_like'),
    path('posts/create_comment', views_posts.create_comment, name='posts_comment'),
    path('posts/delete_comment', views_posts.delete_comment, name='delete_comment'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
