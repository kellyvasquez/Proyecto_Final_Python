from django.shortcuts import render, redirect
from django.http import JsonResponse
from stories.models import Post, Like, commentary
from users.models import User
from users.views import my_login_required


@my_login_required
def listar_posts(request):
	publications = []
	#posts = Post.objects.select_related('user').order_by('-created')
	posts = Post.objects.raw('''
                select * from stories_post
                inner join (select user_id as seguido from stories_follower where follower_user_id = '{}') as seguidos on
                stories_post.user_id = seguidos.seguido or stories_post.user_id = '{}' order by created desc
                '''.format(request.session.get('user_id'), request.session.get('user_id')))
	for post in posts:
		post.likes = Like.objects.all().filter(post_id_id=post.post_id).count()
		post.liked = Like.objects.filter(user_id=request.session.get('user_id')).exists()
		post.comments = commentary.objects.all().filter(post_id_id=post.post_id)
		post.totalcomments = post.comments.count()
	user = User.objects.get(user=request.session.get('user_id'))
	return render(request, 'noticias/noticias.html', {'posts' : posts, 'user': user})

@my_login_required
def new(request):
	user = User.objects.get(user=request.session.get('user_id'))
	return render(request, 'noticias/new.html', {'user':user})

@my_login_required
def create_post(request):
	if request.method == 'POST':
		tipo = request.POST['tipo']
		titulo = request.POST['titulo']
		descripcion = request.POST['descripcion']
		imagen = request.FILES['foto']
		user_id = request.session.get('user_id')
		Post.objects.create(tipo=tipo, nombre=titulo, descripcion=descripcion, imagen=imagen, user_id=user_id)
	return redirect('posts')

@my_login_required
def action_like(request):
	if request.method == 'POST':
		like = request.POST['post_id']
		liked = Like.objects.filter(user_id=request.session.get('user_id'), post_id_id=like)
		if liked.exists() :
			liked.delete()
			response = False
		else:
			Like.objects.create(user_id=request.session.get('user_id'), post_id_id=like)
			response = True
		likes = Like.objects.all().filter(post_id_id=like).count()
		return JsonResponse({'like':response, 'likes': likes})
	return redirect('posts')

@my_login_required
def create_comment(request):
	if request.method == 'POST':
		post = request.POST['post_id']
		comment = request.POST['comment']
		token = request.POST['csrfmiddlewaretoken']
		user = request.session.get('user_id')
		idcomment = commentary.objects.create(user_id=user, post_id_id=post, commentary=comment)
		comments = commentary.objects.all().filter(post_id_id=post).count()
		return JsonResponse({'comment':True, 'total': comments, 'user': user, 'id': idcomment.commentary_id, 'post_id': post, 'token': token})
	return redirect('posts')

@my_login_required
def delete_comment(request):
	if request.method == 'POST':
		comment_id = request.POST['comment_id']
		post = request.POST['post_id']
		commentary.objects.filter(commentary_id=comment_id).delete()
		comments = commentary.objects.all().filter(post_id_id=post).count()
		return JsonResponse({'delete':True, 'total': comments})