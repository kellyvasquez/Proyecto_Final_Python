from django.db import models
from users.models import User

# Create your models here.

class Post(models.Model):
	tipos =((1, "Publicacion"), (2, "Historia"),)
	post_id = models.AutoField(primary_key=True)
	user = models.ForeignKey(User, on_delete=models.CASCADE)
	nombre = models.CharField(max_length=255)
	imagen = models.ImageField(upload_to='posts/fotos')
	descripcion = models.CharField(max_length=255)
	created = models.DateTimeField(auto_now_add=True)
	modified = models.DateTimeField(auto_now=True)
	tipo = models.IntegerField(choices=tipos, default=1)


class Like(models.Model): 
	user = models.ForeignKey(User, on_delete=models.CASCADE)
	post_id = models.ForeignKey(Post, on_delete=models.CASCADE)

class commentary(models.Model): 
	commentary_id = models.AutoField(primary_key=True)
	post_id = models.ForeignKey(Post, on_delete=models.CASCADE)
	user = models.ForeignKey(User, on_delete=models.CASCADE)
	commentary = models.CharField(max_length=255)

class follower(models.Model):
	follower_user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='seguidor')
	user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='seguido')

