function ready(callbackFunc) {
	if (document.readyState !== 'loading') {
	  // Document is already ready, call the callback directly
	  callbackFunc();
	} else if (document.addEventListener) {
	  // All modern browsers to register DOMContentLoaded
	  document.addEventListener('DOMContentLoaded', callbackFunc);
	} else {
	  // Old IE browsers
	  document.attachEvent('onreadystatechange', function() {
		if (document.readyState === 'complete') {
		  callbackFunc();
		}
	  });
	}
  }
  
  ready(function() {
	if (document.querySelector("#tipo"))
		document.querySelector("#tipo").addEventListener("change", function(e) {
			if(this.value == "2") {
				document.querySelector("#div-title").style.display = "none"
			}
			else {
				document.querySelector("#div-title").style.display = "block"
			}
		})
	if(document.querySelectorAll(".like"))
		likes = document.querySelectorAll(".like")
		likes.forEach(function(element){
			element.addEventListener('click', async function(event) {
				event.preventDefault();
				const formulario = new FormData();
				formulario.append('post_id', this.dataset.postid)
				formulario.append('csrfmiddlewaretoken', this.dataset.token)
				response = await fetch('/posts/like', {
					method: 'POST',
					body: formulario
				});
		
				data = await response.json();
				i = this.querySelector('i')
				if(data.like) {
					i.classList.remove('far')
					i.classList.add('fas')
					i.style.color = 'red'
				}
				else {
					i.classList.remove('fas')
					i.classList.add('far')
					i.style.color = 'black'
				}
				this.parentElement.parentElement.querySelector(".count-likes").innerHTML = data.likes
				
			})
		})
	if(document.querySelectorAll(".public-comment"))
		document.querySelectorAll(".public-comment").forEach(function(element){
			element.addEventListener('click', async function(event) {
				event.preventDefault();
				text = this.parentElement.querySelector('textarea').value
				const formulario = new FormData();
				formulario.append('post_id', this.dataset.postid)
				formulario.append('csrfmiddlewaretoken', this.dataset.token)
				formulario.append('comment', text);
				response = await fetch('/posts/create_comment', {
					method: 'POST',
					body: formulario
				});
		
				data = await response.json();
				if(data.comment) {
					parrafo = document.createElement('p');
					parrafo.innerHTML = "<b>"+data.user+": </b>"+text+"<span class='closeButton1' data-id='"+data.id+"' data-token='"+data.token+"' data-postid='"+data.post_id+"'>x</span>";

					parrafo.classList.add('comment');
					this.parentElement.parentElement.parentElement.parentElement.querySelector('.comments').appendChild(parrafo)
					this.parentElement.parentElement.parentElement.parentElement.parentElement.querySelector('.fa-comment').innerHTML = ' ' + data.total
					this.parentElement.querySelector('textarea').value = ''
				}
				
			});
		});

	if(document.querySelectorAll('.comments')) {
		elemento = document.querySelectorAll('.comments')
		total = elemento.querySelector
		elemento.forEach(function(el){
 
              el.addEventListener('click', function(e) {
                path = e.composedPath();
                delegate = document.querySelectorAll('.closeButton1');
                path.forEach(function(node){
                  delegate.forEach(async function(ele){
                    if(node === ele){
                    	const formulario = new FormData();
						formulario.append('comment_id', ele.dataset.id)
						formulario.append('post_id', ele.dataset.postid)
						formulario.append('csrfmiddlewaretoken', ele.dataset.token)

						response = await fetch('/posts/delete_comment', {
							method: 'POST',
							body: formulario
						});
				
						data = await response.json();
						if(data.delete)
                      		ele.parentElement.parentElement.parentElement.querySelector('.fa-comment').innerHTML = ' ' + data.total
                      		ele.parentElement.remove()
                    }
                  });
                });
              });
          })
	}

	if(document.querySelectorAll('.follower')){
		document.querySelectorAll('.follower').forEach(function(el) {
			el.addEventListener('click', async function(ev){
				const formulario = new FormData();
				formulario.append('idfollower', this.dataset.idfollower)
				formulario.append('csrfmiddlewaretoken', this.dataset.token)
				response = await fetch('/users/follow/', {
					method: 'POST',
					body: formulario
				});
		
				data = await response.json();
				seguidores = this.parentElement.parentElement.querySelector('.seguidores')
				if(data.response == 'delete') {
					this.innerHTML = 'Seguir'
					seguidores.innerHTML = parseInt(seguidores.innerHTML) - 1
				}
				else {
					this.innerHTML = 'Dejar de seguir'
					seguidores.innerHTML = parseInt(seguidores.innerHTML) + 1
				}
			});
		});
	}


  });

